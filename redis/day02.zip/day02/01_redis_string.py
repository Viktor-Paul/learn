import redis

r = redis.Redis(host='127.0.0.1',port=6379,db=0)
# 1. set: 设置 {'mystring':'python'}
r.set('mystring','python')
# 2. 获取 mystring 的值,打印查看类型:bytes
print(type(r.get('mystring')))
# 3. 设置 mystring, 当键不存在的时候再设置,存在则不做操作
# 返回值为: False
print(r.setnx('mystring','python'))
# 4. 一次性设置多个键值对,{'mystring2':'mysql','mystring3':'redis'}
#    提示: 参数为字典
r.mset({'mystring2':'mysql','mystring3':'redis'})
# 5. 一次性获取 三个键 的所有值,查看结果类型 : [b'python',...]
mget_list = r.mget('mystring','mystring2','mystring3')
for mget in mget_list:
    print(mget.decode())
# 6. 打印 mystring 的长度
length = r.strlen('mystring')
print(length)
# 数字类型操作
# 7. 设置 number 值为 20
r.set('number','20')
# 8. +10操作
r.incrby('number',10)
# 9. -10操作
r.decrby('number',10)
# 10. +8.88操作
r.incrbyfloat('number',8.88)
# 11. -8.88操作
r.incrbyfloat('number',-8.88)
# 12. 查看number的值
print(r.get('number'))
















