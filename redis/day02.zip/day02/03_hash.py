import redis

r = redis.Redis(host='127.0.0.1',port=6379,db=0)
# 1.新建１条键名为 userinfo 的数据,包含属性 username 值自定义
r.hset('userinfo','username','zhanshen001')
# 2.更改username属性的值(新值自定义)
r.hset('userinfo','username','zhanshen002')
# 3.取出username的值,并打印输出查看类型
# b'zhanshen002'
print(r.hget('userinfo','username'))
# 4.批量添加属性: password=123456,gender=f,height=178
# 第二个参数为字典
user_dict = {
    'password':'123456',
    'gender':'f',
    'height':'178'
}
r.hmset('userinfo',user_dict)

# 5.取出所有数据,打印查看
# 结果为字典 {b'username':b'zhanshen002',b'password':b'123456'}
all_data = r.hgetall('userinfo')
print('all_data:',all_data)

# 6.删除height属性
r.hdel('userinfo','height')
# 7.取出所有属性名,打印查看类型
# 列表 [b'username',b'password',b'gender']
key_names = r.hkeys('userinfo')
# print('key_names:',key_names)
# 8.取出所有属性值,打印查看类型
# 列表 [b'zhanshen002',b'123456',b'm']
key_values = r.hvals('userinfo')
# print('key_values:',key_values)















