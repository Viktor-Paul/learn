import redis

r = redis.Redis(host='localhost',port=6379,db=0)
# zadd ranking 1 song1 1 song2 1 song3
# 注意: 参数为字典类型{'元素':分值}
r.zadd('ranking',{'song1':1,'song2':1,'song3':1,'song4':1})
r.zadd('ranking',{'song5':1,'song6':1,'song7':1})
r.zadd('ranking',{'song8':1,'song9':1})

# 给任意3个元素增加任意分值
r.zincrby('ranking',50,'song3')
r.zincrby('ranking',80,'song5')
r.zincrby('ranking',90,'song8')
# 获取排行榜前3名
# [(元素,分值),(),(),()]
result = r.zrevrange('ranking',0,2,withscores=True)

i = 1
for r in result:
    print('第{}名:{} 播放量:{}'\
                      .format(i,r[0].decode(),int(r[1])))
    i += 1

# 第1名: 海阔天空 播放量: 6666
# 第2名:
# 第3名:













