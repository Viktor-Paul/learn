## 标量、向量、矩阵、相关运算与性质

### 标量（scalar）

　　**标量**（**Scalar**）又称**纯量**，一个标量就是一个单独的数或者字符，一般用小写的变量名称表示。

###  向量（vector）

　　**向量**（vector）又称**矢量**，一个向量就是一组数，这些数是有序排列的。可以按照索引的序列确定每个单独的数。在几何空间中可以代表一个“点”，也可表示为空间坐标系原点到这个点的有向线段。

表示：大写字母或者带箭头的字符 $\vec a, \overrightarrow{AB}$ .
$$
A = 
\left[
\begin{array}{c}
红色\\
橙色\\
黄色\\
\end{array}
\right]
\quad\quad\quad 
B = 
\left[
\begin{array}{c}
7.5\\
6.8\\
5.2\\
\end{array}
\right]
\quad\quad\quad 
C = 
\left[
\begin{array}{c}
7.1\\
7.4\\
10.3\\
\end{array}
\right]
$$
性质：有向线段，有大小，有夹角。

###  矩阵（matrix）

　　矩阵是具有相同特征和纬度的对象的集合，表现为一张二维数据表。其意义是一个对象表示为矩阵中的一行，一个特征表示为矩阵中的一列，每个特征都有数值型的取值。 
　　把上述多个列向量沿水平方向合并在一起，就形成了m行n列的“数据表”。称为m行n列的“矩阵”。矩阵属于二维数据结构。
$$
D = \begin{bmatrix}
红色 & 7.5 & 7.1\\
橙色 & 6.8 & 7.4\\
黄色 & 5.2 & 10.3\\
  \end{bmatrix}
$$

### 矩阵的运算

#### **矩阵的加减法**

${\displaystyle m\times n}$ 矩阵 ${\displaystyle \mathbf {A} }$ 和 ${\displaystyle \mathbf {B} }$ 的和（差）：${\displaystyle \mathbf {A} \pm \mathbf {B} }$ 为一个 ${\displaystyle m\times n}$ 矩阵，其中每个元素是 ${\displaystyle \mathbf {A} }$ 和 ${\displaystyle \mathbf {B} }$ 相应元素的和（差）,

$(\mathbf {A}+\mathbf {B})_{i,j}=\mathbf {A} _{i,j}\pm \mathbf {B} _{i,j}$ , 其中 $1 \leq i \leq m, 1 \leq j \leq n$ . 
$$
10 + 
\left[
\begin{array}{c}
1 & 2\\
4 & 5\\
7 & 8\\
\end{array}
\right]
= 
\left[
\begin{array}{c}
11 & 12\\
14 & 15\\
17 & 18\\
\end{array}
\right]

\quad\quad\quad

\left[
\begin{array}{c}
1 & 2\\
3 & 4\\
5 & 6\\
\end{array}
\right]
+ 
\left[
\begin{array}{c}
1 & 2\\
3 & 4\\
5 & 6\\
\end{array}
\right]
= 
\left[
\begin{array}{c}
2 & 4\\
6 & 8\\
10 & 12\\
\end{array}
\right]
$$

$$
10 - 
\left[
\begin{array}{c}
1 & 2\\
3 & 4\\
5 & 6\\
\end{array}
\right]
= 
\left[
\begin{array}{c}
9 & 8\\
7 & 6\\
5 & 4\\
\end{array}
\right]
​
\quad\quad\quad\quad
​
\left[
\begin{array}{c}
1 & 2\\
3 & 4\\
5 & 6\\
\end{array}
\right]
-
\left[
\begin{array}{c}
1 & 1\\
\end{array}
\right]
= 
\left[
\begin{array}{c}
0 & 1\\
2 & 3\\
4 & 5\\
\end{array}
\right]
$$

#### 数与矩阵相乘

标量 ${\displaystyle c}$ 与矩阵${\displaystyle \mathbf {A} }$ 的数乘： ${\displaystyle c\mathbf {A} }$ 的每个元素是A的相应元素与c的乘积，

$ (cA)_{i,j}=c \cdot A_{i,j} $
$$
10 \times 
\left[
\begin{array}{c}
1 & 2\\
4 & 5\\
7 & 8\\
\end{array}
\right]
= 
\left[
\begin{array}{c}
10 & 20\\
40 & 50\\
70 & 80\\
\end{array}
\right]

\quad\quad\quad
$$


#### 矩阵与矩阵相乘

两个矩阵的乘法仅当第一个矩阵A的列数(column)和另一个矩阵B的行数(row)相等时才能定义。

如A是m x n 矩阵和B是 n x p矩阵，它们的乘积AB 是一个m x p 矩阵，它的一个元素
$$
[AB]_{i,j}=A_{i,1} B_{1,j}+A_{i,2} B_{2,j}+...+A_{i,n} B_{n,j}=\sum_{r=1}^n A_{i,r} B_{r,j}
\\
其中 1 \leq i \leq m, 1 \leq j \leq n
$$

$$
\left[
\begin{array}{c}
1 & 2 & 3\\
4 & 5 & 6\\
\end{array}
\right]
\times 
\left[
\begin{array}{c}
1 & 2\\
3 & 4\\
5 & 6\\
\end{array}
\right]
= 
\left[
\begin{array}{c}
22 & 28\\
49 & 64\\
\end{array}
\right]
$$

### 矩阵的转置

把矩阵A的行换成同序数的列得到一个新矩阵，叫做矩阵A的转置矩阵， 记为 $A^T$ .
$$
A = \begin{bmatrix}
1 & 2 & 3\\
4 & 5 & 6\\
  \end{bmatrix}
则 \quad 
A^T=\begin{bmatrix}
1 & 4 \\
2 & 5\\
3 & 6\\
  \end{bmatrix}
$$

### 特殊矩阵

**方阵：** 行数与列数相等的矩阵为方阵。n x n
$$
\left[\begin{array}{c}1 & 2\\3 & 4\\\end{array}\right]\quad\quad\quad\left[\begin{array}{c}1 & 2 & 2\\3 & 4 & 4\\3 & 4 & 4\\\end{array}\right]
$$
**零矩阵：** 矩阵中每个元素都为0。
$$
\left[\begin{array}{c}0 & 0 & 0\\0 & 0 & 0\\0 & 0 & 0\\\end{array}\right]
$$
**对角矩阵：**    主对角线之外的元素都是0的矩阵。
$$
\left[
\begin{array}{c}
1 & 0 & 0\\
0 & 2 & 0\\
0 & 0 & 3\\
\end{array}
\right]
$$
**单位矩阵：** 主对角线元素都是1的对角矩阵。
$$
\left[
\begin{array}{c}
1 & 0 & 0\\
0 & 1 & 0\\
0 & 0 & 1\\
\end{array}
\right]
$$

## 距离算法

### 1. 欧式距离

在数学中，**欧几里得距离**或**欧氏距离**是欧几里得空间中两点间“普通”（即直线）距离。使用这个距离，欧氏空间成为度量空间。使用这个距离，欧氏空间成为度量空间。相关联的范数 $ L_2$ 称为欧几里得范数。(向量 $L_2$ 范数也称作向量的模)
$$
𝑑_{x,y}=\sqrt{(𝑥_1−𝑥_2)^2+(𝑦_1−𝑦_2)^2}
$$
![img](images/300px-Manhattan_distance.svg.png)

### 2. 曼哈顿距离（街区距离）

曼哈顿距离的命名原因是从规划为方型建筑区块的城市（如曼哈顿）间，最短的行车路径而来（忽略曼哈顿的单向车道以及只存在于3、14大道的斜向车道）。任何往东三区块、往北六区块的的路径一定最少要走九区块，没有其他捷径。
$$
𝑑_{x,y}=|𝑥_1−𝑥_2 |+|𝑦_1−𝑦_2|
$$

### 3.切比雪夫距离（棋盘距离）

国际象棋棋盘上二个位置间的切比雪夫距离是指王要从一个位子移至另一个位子需要走的步数。由于王可以往斜前或斜后方向移动一格，因此可以较有效率的到达目的的格子。其又称无限范数距离。在二维空间里，为国王在棋盘上的两个方块间移动所需之最少步数。

![âæ£çè·ç¦»âçå¾çæç´¢ç»æ](images/01300000009075133329227359321.jpg)

在平面几何中，若二点*p*及*q*的直角坐标系坐标为 ${\displaystyle (x_{1},y_{1})}$及${\displaystyle (x_{2},y_{2})}$，则切比雪夫距离为

![1568113935760](images/1568113935760.png)

所以位置F6和位置E2的切比雪夫距离为4。任何一个不在棋盘边缘的位置，和周围八个位置的切比雪夫距离都是1。

![1568113673744](images/1568113673744.png)

### 3. 明氏距离

**明氏距离**又叫做明可夫斯基距离，是欧氏空间中的一种测度，被看做是欧氏距离和曼哈顿距离的一种推广。
$$
𝑑_{x,y}=\bigg(\sum_{k=1}^n (x_{1k} - x_{2k})\bigg) ^{\frac{1}{p}}
$$
当p=1时，是曼哈顿距离，相关联的范数 $ L_1$ 称为欧几里得范数。

当p=2时，是欧氏距离，相关联的范数 $ L_2$ 称为欧几里得范数。

当p趋于正无穷时，是切比雪夫距离，又称无限范数距离。

![1568114279769](images/1568114279769.png)



### 4. 夹角余弦相似度

![âå¤¹è§ä½å¼¦è·ç¦"âçå¾çæç´¢ç"æ](images/bg2013032005.png)
$$
𝑐𝑜𝑠\theta=\frac{\vec{a} × \vec{b}}{|\vec{a}||\vec{b}|}=\frac{𝑥_1 𝑥_2+𝑦_1 𝑦_2}{\sqrt{𝑥_1^2+𝑦_1^2}\sqrt{𝑥_2^2+𝑦_2^2 } }
$$



## 用pandas进行数据清洗

#### 数据分析的步骤：

1. ##### 定义挖掘目标

2. ##### 数据取样

   1. 标准
      1. 资料完整无缺，各类指标项齐全
      2. 数据准确无误，反应的都是正常（而不是异常）状态下的水平
      3. 相关性，可靠性，有效性
   2. 方式：
      1. 随机抽样
      2. 等距抽样
      3. 分层抽样
      4. 分类抽样

3. ##### 数据探索

   1. 异常值分析
   2. 缺失值分析
   3. 相关性分析
   4. 周期性分析
   5. 分布分析
   6. 对比分析
   7. 统计量分析
   8. 贡献度分析

4. ##### 数据预处理

   1. 数据清洗
   2. 数据集成
   3. 数据变换
   4. 数据规约

5. ##### 挖掘建模

   1. 机器学习算法

6. ##### 模型评价

#### 航空公司客户价值分析

##### 1.项目背景和挖掘目标：

准确的客户分类的结果是企业优化营销资源的重要依据，本文利用了航空公司的部分数据，利用Kmeans聚类方法，对航空公司的客户进行了分类，来识别出不同的客户群体，从来发现有用的客户，从而对不同价值的客户类别提供个性化服务，指定相应的营销策略。

**目标**：

（1）借助航空公司数据，对客户进行分类；

（2）对不同类别的客户进行特征分析，比较不同类别客户的价值分析；

（3）对不同价值的客户类别进行个性化服务，制定相应的营销策略。

#####  **2.分析方法和过程：**

**数据取样**：

详细客户信息表：

<img src="images/1568101981407.png" alt="1568101981407" style="zoom:100%;" />

客户属性说明表：

<img src="images/1568101936648.png" alt="1568101936648" style="zoom:80%;" />



航空公司识别客户价值模型（LRFMC）指标如下：

| 指标                | 含义                                             |
| ------------------- | ------------------------------------------------ |
| 客户关系长度L :     | 会员入会时间距观测窗口结束的月份                 |
| 消费时间间隔R：     | 客户最近一次乘坐公司飞机距观测窗口结束的月数     |
| 消费频率F：         | 客户在观测窗口内乘坐公司飞机的次数               |
| 飞行里程M：         | 客户在观测窗口内飞行里程                         |
| 折扣系数的平均值C： | 客户在观测窗口内乘坐舱位所对应的折扣系数的平均值 |

航空客运信息挖掘的步骤：

![1565764978090](images/1565764978090.png)



（1）从航空公司的数据源中进行选择性抽取与新增数据抽取分别形成历史数据和增量数据；

（2）对步骤1中形成的两个数据集进行数据探索分析和预处理，包括数据缺失值和异常值分析，数据属性的规约、清洗和变换；

（3）利用步骤2中的处理的数据进行建模，基于旅客价值的LRFMC模型进行客户分类，对各个客户群进行特征分析，识别出最有价值的客户；

（4）针对模型结果得到不同价值的客户，采用不同的营销手段，提供定制化的服务。

**数据抽取**

以2014-03-31为结束时间，选取宽度为2年的时间段作为分析观测窗口，抽取观测窗口内有乘机记录的所有客户的详细数据形成**历史数据**。

对于后续新增的客户详细信息，以后续新增数据中最新的时间点作为结束时间，采用上述同样的方法进行抽取，形成**增量数据**。

##### 3.数据探索分析

缺失值分析和异常值分析

比如票价为空值，票价最小值为0、折扣率最小值为0、总飞行里程数大于零的记录。

```python
#-*- coding: utf-8 -*- 
#对数据进行基本的探索
#返回缺失值个数以及最大最小值

import pandas as pd

datafile= '../data/air_data.csv' #航空原始数据,第一行为属性标签
resultfile = '../tmp/explore.xls' #数据探索结果表

data = pd.read_csv(datafile, encoding = 'utf-8') #读取原始数据，指定UTF-8编码（需要用文本编辑器将数据装换为UTF-8编码）

explore = data.describe(percentiles = [], include = 'all').T 
#包括对数据的基本描述，percentiles参数是指定计算多少的分位数表（如1/4分位数、中位数等）；T是转置，转置后更方便查阅
explore['null'] = len(data)-explore['count'] #describe()函数自动计算非空值数，需要手动计算空值数

explore = explore[['null', 'max', 'min']]
explore.columns = [u'空值数', u'最大值', u'最小值'] #表头重命名
'''这里只选取部分探索结果。
describe()函数自动计算的字段有count（非空值数）、unique（唯一值数）、top（频数最高者）、freq（最高频数）、mean（平均值）、std（方差）、min（最小值）、50%（中位数）、max（最大值）'''

explore.to_excel(resultfile) #导出结果
```

![1568100424678](images/1568100424678.png)

##### 4.数据预处理

数据清洗、属性规约和数据变换

**1. 数据清洗**

由于原始数据量比较大，上述被定义为缺失值和异常值的样本量很小，对问题的分学习影响不大，因此选择的是剔除缺失值和异常值。

1. 丢弃票价为空的记录；

2. 丢弃票价为0，平均折扣率不为0，总飞行公里数大于0的记录。

```python
#-*- coding: utf-8 -*-
#数据清洗，过滤掉不符合规则的数据

import pandas as pd

datafile= '../data/air_data.csv' #航空原始数据,第一行为属性标签
cleanedfile = '../tmp/data_cleaned.csv' #数据清洗后保存的文件

data = pd.read_csv(datafile,encoding='utf-8') #读取原始数据，指定UTF-8编码（需要用文本编辑器将数据装换为UTF-8编码）

data = data[data['SUM_YR_1'].notnull()*data['SUM_YR_2'].notnull()] #票价非空值才保留

#只保留票价非零的，或者平均折扣率与总飞行公里数同时不为0的记录。
index1 = data['SUM_YR_1'] != 0
index2 = data['SUM_YR_2'] != 0
index3 = (data['SEG_KM_SUM'] == 0) & (data['avg_discount'] == 0) #该规则是“与”
data = data[index1 | index2 | index3] #该规则是“或”

data.to_csv(cleanedfile) #导出结果
```

**2. 属性规约**
基于航空公司客户价值的LRFMC模型，选择与LRFMC指标相关的6个属性，其中选取了LOAD_TIME(观测窗口的结束时间)，FFP_DATE(观测窗口的开始时间)，LAST_TO_END(最后一次乘机时间至观测窗口结束时长)，FLIGHT_COUNT(观测窗口的飞行次数)，SEG_KM_SUM(观测窗口的总飞行公里数)，AVG_DISCOUNT(平均折扣率)，删除其余不必要的属性。
![1568104117507](images/1568104117507.png)

**3. 数据变换**

- L=LOAD_TIME - FFP_DATE(观测窗口的结束时间 - 入会时间)
- R=LAST_TO_END(最后一次乘坐飞机距观测窗口结束的时长)
- F=FLIGHT_COUNT(观测窗口内的飞行次数)
- M=SEG_KM_SUM(观测窗口内的总飞行里程)
- C=AVG_DISCOUNT(平均折扣率)

LRFMC指标取值范围：

![1568104262136](images/1568104262136.png)

```python
#-*- coding: utf-8 -*-
#标准差标准化

import pandas as pd

datafile = '../data/zscoredata.xls' #需要进行标准化的数据文件；
zscoredfile = '../tmp/zscoreddata.xls' #标准差化后的数据存储路径文件；

#标准化处理
data = pd.read_excel(datafile)
data = (data - data.mean(axis = 0))/(data.std(axis = 0)) #简洁的语句实现了标准化变换，类似地可以实现任何想要的变换。
data.columns=['Z'+i for i in data.columns] #表头重命名。

data.to_excel(zscoredfile, index = False) #数据写入
```

标准化处理之后的数据集：

![1568104438809](images/1568104438809.png)

